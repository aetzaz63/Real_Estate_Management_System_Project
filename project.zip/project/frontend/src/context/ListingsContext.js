import React, { createContext, useState, useEffect } from 'react';
import axios from 'axios';

const ListingsContext = createContext();

const ListingsProvider = ({ children }) => {
  const [listings, setListings] = useState([]);

  const fetchListings = async () => {
    try {
      const response = await axios.get('/api/listings');
      setListings(response.data);
    } catch (error) {
      console.error('Error fetching listings:', error);
    }
  };

  const addListing = async (listingData) => {
    try {
      const response = await axios.post('/api/listings', listingData);
      setListings([...listings, response.data]);
    } catch (error) {
      console.error('Error adding listing:', error);
      throw error;
    }
  };

  const updateListing = async (id, updatedData) => {
    try {
      const response = await axios.put(`/api/listings/${id}`, updatedData);
      setListings(listings.map(listing => (listing.id === id ? response.data : listing)));
    } catch (error) {
      console.error('Error updating listing:', error);
      throw error;
    }
  };

  const deleteListing = async (id) => {
    try {
      await axios.delete(`/api/listings/${id}`);
      setListings(listings.filter(listing => listing.id !== id));
    } catch (error) {
      console.error('Error deleting listing:', error);
      throw error;
    }
  };

  useEffect(() => {
    fetchListings();
  }, []);

  return (
    <ListingsContext.Provider value={{ listings, addListing, updateListing, deleteListing }}>
      {children}
    </ListingsContext.Provider>
  );
};

export { ListingsContext, ListingsProvider };
