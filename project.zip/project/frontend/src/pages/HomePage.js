import React, { useEffect, useState } from 'react';
import axios from 'axios';
import List from '../components/List';

const HomePage = () => {
  const [listings, setListings] = useState([]);

  useEffect(() => {
    const fetchListings = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/listings');
        setListings(response.data);
      } catch (error) {
        console.error('Error fetching listings:', error);
      }
    };

    fetchListings();
  }, []);

  return (
    <div>
      <h1 className="text-center mt-4">Real Estate Listings</h1>
      <List listings={listings} />
    </div>
  );
};

export default HomePage;
