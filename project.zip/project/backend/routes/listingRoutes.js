const express = require('express');
const { getListings, getListingById, createListing, updateListing, deleteListing } = require('../controllers/listingController');
const { protect } = require('../middlewares/authMiddleware');

const ListingsController = require('../controllers/listingController');
const upload = require('../middlewares/upload');


const router = express.Router();



router.post('/', upload.single('image'), ListingsController.createListing);

router.route('/')
  .get(getListings)
  .post(protect, createListing);

router.route('/:id')
  .get(getListingById)
  .put(protect, updateListing)
  .delete(protect, deleteListing);

module.exports = router;
