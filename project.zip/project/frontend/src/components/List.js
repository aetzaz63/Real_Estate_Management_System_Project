import React from 'react';
import Card from './Card';

const List = ({ listings }) => (
  <div className="container mt-5">
    <div className="row">
      {listings.length > 0 ? (
        listings.map(listing => (
          <div className="col-md-4 mb-4" key={listing._id}>
            <Card listing={listing} />
          </div>
        ))
      ) : (
        <div className="col-12">
          <p>No listings available.</p>
        </div>
      )}
    </div>
  </div>
);

export default List;
