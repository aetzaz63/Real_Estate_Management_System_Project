import React from 'react';

const Card = ({ listing }) => {
  return (
    <div className="card">
      <img
        src={`http://localhost:5000/${listing.imageUrl}`} // Adjust this URL if necessary
        className="card-img-top"
        alt={listing.title}
        style={{ height: '200px', objectFit: 'cover' }} // Style to maintain image aspect ratio
      />
      <div className="card-body">
        <h5 className="card-title">{listing.title}</h5>
        <p className="card-text">{listing.description}</p>
        <p className="card-text"><strong>Price:</strong> ${listing.price}</p>
        <p className="card-text"><strong>Location:</strong> {listing.location}</p>
        <a href={`mailto:${listing.email}`} className="btn btn-primary">Contact Seller</a>
      </div>
    </div>
  );
};

export default Card;
