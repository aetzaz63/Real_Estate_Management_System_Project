import React from 'react';
import ListingForm from '../components/ListingForm';

const ListingFormPage = () => (
  <div className="container mt-5">
    <h2>Create Listing</h2>
    <ListingForm />
  </div>
);

export default ListingFormPage;
