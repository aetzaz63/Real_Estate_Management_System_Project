import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';

const ListingForm = () => {
  const handleSubmit = async (values) => {
    const formData = new FormData();
    formData.append('title', values.title);
    formData.append('description', values.description);
    formData.append('price', values.price);
    formData.append('location', values.location);
    formData.append('image', values.image);
    formData.append('email', values.email);
  
    try {
      await axios.post('http://localhost:5000/api/listings', formData, {
        headers: { 
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'multipart/form-data'
        }
      });
      alert('Listing created');
    } catch (error) {
      console.error('Error details:', error.response?.data);
      alert('Error creating listing. Please try again.');
    }
  };
  
  

  const validationSchema = Yup.object({
    title: Yup.string().required('Title is required'),
    description: Yup.string().required('Description is required'),
    price: Yup.number().required('Price is required').positive('Price must be a positive number'),
    location: Yup.string().required('Location is required'),
    email: Yup.string().email('Invalid email format').required('Email is required'),
    image: Yup.mixed().required('An image is required')
  });

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Create Listing</h2>
      <Formik
        initialValues={{ title: '', description: '', price: '', location: '', email: '', image: null }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ setFieldValue }) => (
          <Form>
            <div className="form-group">
              <label htmlFor="title">Title</label>
              <Field type="text" className="form-control" id="title" name="title" />
              <ErrorMessage name="title" component="div" className="text-danger" />
            </div>
            <div className="form-group">
              <label htmlFor="description">Description</label>
              <Field as="textarea" className="form-control" id="description" name="description" />
              <ErrorMessage name="description" component="div" className="text-danger" />
            </div>
            <div className="form-group">
              <label htmlFor="price">Price</label>
              <Field type="number" className="form-control" id="price" name="price" />
              <ErrorMessage name="price" component="div" className="text-danger" />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <Field type="email" className="form-control" id="email" name="email" />
              <ErrorMessage name="email" component="div" className="text-danger" />
            </div>
            <div className="form-group">
              <label htmlFor="location">Location</label>
              <Field type="text" className="form-control" id="location" name="location" />
              <ErrorMessage name="location" component="div" className="text-danger" />
            </div>
            <div className="form-group">
              <label htmlFor="image">Image</label>
              <input 
                type="file" 
                className="form-control" 
                id="image" 
                name="image" 
                accept="image/*" 
                onChange={(event) => setFieldValue('image', event.currentTarget.files[0])}
              />
              <ErrorMessage name="image" component="div" className="text-danger" />
            </div>
            <button type="submit" className="btn btn-primary">Submit</button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default ListingForm;
