const Listing = require('../models/Listing');
const path = require('path');


// Get all listings
exports.getListings = async (req, res) => {
  try {
    const listings = await Listing.find();
    res.json(listings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get a single listing
exports.getListingById = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id);

    if (!listing) {
      return res.status(404).json({ message: 'Listing not found' });
    }

    res.json(listing);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createListing = async (req, res) => {
  const { title, description, price, location, email } = req.body;
  const imageUrl = req.file ? req.file.path.replace('uploads\\', '') : null;

  // Debugging statement
  console.log('Request User:', req.user);

  if (!req.user) {
    return res.status(401).json({ message: 'User not authenticated' });
  }

  if (!title || !description || !price || !location || !email) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    const listing = await Listing.create({
      title,
      description,
      price,
      location,
      email,
      imageUrl,
      user: req.user.id,
    });

    res.status(201).json(listing);
  } catch (error) {
    console.error('Error creating listing:', error);
    res.status(500).json({ message: error.message });
  }
};


// Update a listing
exports.updateListing = async (req, res) => {
  const { title, description, price, location, email } = req.body;
  const imageUrl = req.file ? req.file.path : null; // Get the image URL from multer

  try {
    let listing = await Listing.findById(req.params.id);

    if (!listing) {
      return res.status(404).json({ message: 'Listing not found' });
    }

    if (listing.user.toString() !== req.user.id) {
      return res.status(401).json({ message: 'Not authorized' });
    }

    listing = await Listing.findByIdAndUpdate(
      req.params.id,
      { 
        title, 
        description, 
        price, 
        location, 
        email,
        imageUrl: imageUrl || listing.imageUrl // Update imageUrl if a new one is provided
      },
      { new: true }
    );

    res.json(listing);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Delete a listing
exports.deleteListing = async (req, res) => {
  try {
    const listing = await Listing.findById(req.params.id);

    if (!listing) {
      return res.status(404).json({ message: 'Listing not found' });
    }

    if (listing.user.toString() !== req.user.id) {
      return res.status(401).json({ message: 'Not authorized' });
    }

    await Listing.findByIdAndDelete(req.params.id);

    res.json({ message: 'Listing removed' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
