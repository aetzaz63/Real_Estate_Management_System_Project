import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { Button, Form as BootstrapForm } from 'react-bootstrap';

const ListingSchema = Yup.object().shape({
  title: Yup.string().required('Title is required'),
  description: Yup.string().required('Description is required'),
  price: Yup.number().required('Price is required'),
  location: Yup.string().required('Location is required')
});

const ListingForm = ({ onSubmit }) => (
  <Formik
    initialValues={{ title: '', description: '', price: '', location: '' }}
    validationSchema={ListingSchema}
    onSubmit={values => onSubmit(values)}
  >
    {() => (
      <Form>
        <BootstrapForm.Group controlId="formTitle">
          <BootstrapForm.Label>Title</BootstrapForm.Label>
          <Field name="title" type="text" className="form-control" />
          <ErrorMessage name="title" component="div" className="text-danger" />
        </BootstrapForm.Group>

        <BootstrapForm.Group controlId="formDescription">
          <BootstrapForm.Label>Description</BootstrapForm.Label>
          <Field name="description" as="textarea" className="form-control" />
          <ErrorMessage name="description" component="div" className="text-danger" />
        </BootstrapForm.Group>

        <BootstrapForm.Group controlId="formPrice">
          <BootstrapForm.Label>Price</BootstrapForm.Label>
          <Field name="price" type="number" className="form-control" />
          <ErrorMessage name="price" component="div" className="text-danger" />
        </BootstrapForm.Group>

        <BootstrapForm.Group controlId="formLocation">
          <BootstrapForm.Label>Location</BootstrapForm.Label>
          <Field name="location" type="text" className="form-control" />
          <ErrorMessage name="location" component="div" className="text-danger" />
        </BootstrapForm.Group>

        <Button type="submit" variant="primary">Submit</Button>
      </Form>
    )}
  </Formik>
);

export default ListingForm;
