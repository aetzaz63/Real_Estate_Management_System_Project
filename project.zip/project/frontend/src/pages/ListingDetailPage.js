import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ListingDetailPage = ({ params }) => {
  const [listing, setListing] = useState(null);
  const { id } = params;

  useEffect(() => {
    const fetchListing = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/listings/${id}`);
        setListing(res.data);
      } catch (error) {
        console.error('Error fetching listing', error);
      }
    };
    fetchListing();
  }, [id]);

  const handleContact = () => {
    const sellerEmail = listing.sellerEmail; // Assuming you store the seller's email in the listing
    window.location.href = `mailto:${sellerEmail}`;
  };

  return (
    <div className="container mt-5">
      {listing ? (
        <>
          <h1>{listing.title}</h1>
          <img src={listing.imageUrl} alt={listing.title} className="img-fluid mb-4" />
          <p>{listing.description}</p>
          <p><strong>${listing.price}</strong></p>
          <p><small className="text-muted">{listing.location}</small></p>
          <button className="btn btn-primary" onClick={handleContact}>Contact Seller</button>
        </>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

export default ListingDetailPage;
